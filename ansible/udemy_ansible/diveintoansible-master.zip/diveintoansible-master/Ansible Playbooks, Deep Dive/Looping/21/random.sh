#!/bin/bash
echo $((1 + RANDOM % 10))
